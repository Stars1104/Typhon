import { Footer, Navbar } from "../landingcomponents";
import {
  About,
  Explore,
  Feedback,
  GetStarted,
  Hero,
  Insights,
  WhatsNew,
  World,
} from "../sections";
import PulseButton from "../landingcomponents/PlusButton";
import KarinaModel from "../landingcomponents/KarinaModel";

export default function Home() {
  return (
    <main className="bg-transparent overflow-hidden max-w-7xl mx-auto px-12">
      <Navbar />
      <PulseButton />
      <Hero />
      {/* <KarinaModel /> */}
      <section className="relative">
        <About />
        <hr className="py-8" />
        <WhatsNew />
        <hr className="py-8" />
        <GetStarted />
        <hr className="py-8" />
        <Explore />
        <hr className="py-8" />
        <Insights />
        <hr className="py-8" />
        <World />
        <hr className="py-8" />
        {/* <Feedback /> */}
        <hr />
      </section>
      {/* <Footer /> */}
    </main>
  );
}
