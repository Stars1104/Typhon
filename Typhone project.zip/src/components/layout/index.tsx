import React from "react";
import Header from "../layout/header";
import Sidebar from "../layout/sidebar";

export const Layout = ({ children }: { children: React.ReactNode }) => {
    return (
        <>
            <Header />
            <div className="flex border-collapse overflow-hidden bg-[#161616]">
                <Sidebar />
                <div className="bg-[#161616] flex-1 pt-16 bg-secondary/10 pb-1">
                    {children}
                </div>
            </div>
        </>
    );
};