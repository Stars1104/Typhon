"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { TitleText, ExploreCard, TypingText } from "../landingcomponents";
import { staggerContainer } from "../utils/motion";
import { exploreWorlds } from "../constants";

const Explore = () => {
  const [active, setActive] = useState("world-2");

  return (
    <section className="paddings" id="explore">
      <motion.div
        variants={staggerContainer(0.25, 0.25)}
        initial="hidden"
        whileInView="show"
        viewport={{ once: false, amount: 0.25 }}
        className="innerWidth mx-auto flex flex-col"
      >
        <TypingText title="| Our Julia Agent" textStyles="text-left" />

        <div className="mt-[50px] flex lg:flex-row flex-col min-h-[70wh] gap-5">
          {exploreWorlds.map((world, index) => (
            <ExploreCard
              key={world.title}
              // content={world.content}
              {...world}
              active={active}
              index={index}
              handleClick={setActive}
            />
          ))}
        </div>
      </motion.div>
    </section>
    
  );
};

export default Explore;
