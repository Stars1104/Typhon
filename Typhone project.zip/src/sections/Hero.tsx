"use client";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { slideIn, staggerContainer, textVariant } from "../utils/motion";

const Hero = () => (
  <section className="yPaddings sm:p-16 p-0">
    <motion.div
      variants={staggerContainer(0.25, 0.25)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: false, amount: 0.25 }}
      className="innerWidth mx-auto flex flex-col"
    >
      <div className="relative z-10 text-center">
        <motion.h1 variants={textVariant(1.1)}>
          {/* Cognix Ai */}
          <Image
            src="/logo.png"
            width={500}
            height={24}
            alt="menu"
            className="mx-auto"
          />
        </motion.h1>
      </div>
      <motion.div
        variants={slideIn("right", "tween", 0.2, 1)}
        className="relative w-full md:-mt-[20px] -mt-[12px]"
      >
        <div className="absolute w-full h-[300px]  rounded-tl-[140px] z-[0] -top-[30px]" />
        <div className="w-full flex justify-end sm:-mt-[45px] -mt-[50px]  z-10">
          <video width="1280" className="border border-4 border-[#eaccb1]" style={{borderRadius:"20px"}} controls loop autoPlay={true}>
            <source src="/introducing.mp4" type="video/mp4" className="sm:w-[155px] w-[100px] sm:h-[155px] h-[100px] object-contain "  />
            Your browser does not support the video tag.
          </video>
          {/* <Image
            src="/scene.jpg"
            width={1200}
            height={24}
            alt="menu"
            className="mx-auto"
          /> */}
        </div>
      </motion.div>
    </motion.div>
  </section>
);

export default Hero;
