"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { TitleText, TypingText } from "../landingcomponents";
import { staggerContainer, fadeIn } from "../utils/motion";

const World = () => (
  <section className="paddings relative z-10">
    <motion.div
      variants={staggerContainer(0.25, 0.25)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: false, amount: 0.25 }}
      className="innerWidth mx-auto flex flex-col"
    >
      <TypingText title="| Cogn Token" textStyles="text-left" />
      <TitleText
        title={
          <>
            Tokenomics |
          </>
        }
        textStyles="text-right"
      />
      <h1 className="font-normal text-[24px] text-secondary-white">
        The core platform token used for governance, staking, rewards, bonding, and unlocking premium features
      </h1>
      <h1 className="font-normal text-[24px] text-secondary-white">
        Cognix AI has a total supply of 800,000,000 tokens, allocated across various categories
      </h1>
      <motion.div
        variants={fadeIn("up", "tween", 0.3, 1)}
        className="relative mt-[68px] flex w-full h-[550px]"
      >
        <Image
          src="/map.png"
          width={1000}
          height={1000}
          priority={true}
          alt="map"
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-20 right-20 w-[70px] h-[70px] p-[6px] rounded-full bg-[#5D6680]">
          <Image
            src="/people-01.png"
            width={1000}
            height={1000}
            alt="people"
            className="w-full h-full"
          />
        </div>
        <div className="absolute top-10 left-20 w-[70px] h-[70px] p-[6px] rounded-full bg-[#5D6680]">
          <Image
            src="/people-02.png"
            width={1000}
            height={1000}
            alt="people"
            className="w-full h-full"
          />
        </div>
        <div className="absolute top-1/2 left-[45%] w-[70px] h-[70px] p-[6px] rounded-full bg-[#5D6680]">
          <Image
            src="/people-03.png"
            width={1000}
            height={1000}
            alt="people"
            className="w-full h-full"
          />
        </div>
      </motion.div>
    </motion.div>
  </section>
);

export default World;
