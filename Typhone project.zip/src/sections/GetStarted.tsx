"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { StartSteps, TitleText, TypingText } from "../landingcomponents";
import { staggerContainer, fadeIn, planetVariants } from "../utils/motion";
import { startingFeatures } from "../constants";
import { LoopRepeat } from "three";

const GetStarted = () => (
  <section className="paddings relative z-10">
    <motion.div
      variants={staggerContainer(0.25, 0.25)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: false, amount: 0.25 }}
      className="innerWidth mx-auto flex lg:flex-row flex-col gap-8"
    >
      <motion.div
        variants={planetVariants("left")}
        className="flex-[0.5] flexCenter"
      >
        <div className="w-full flex justify-end sm:-mt-[45px] -mt-[50px]  z-10">
          <video width="1280" id="karina_video" className="border border-4 border-[#4d9dcb]" style={{borderRadius:"20px"}} autoPlay={true} controls loop>
            <source src="/karina.mp4" type="video/mp4" className="sm:w-[155px] w-[100px] sm:h-[155px] h-[100px] object-contain "  />
            Your browser does not support the video tag.
          </video>
        </div>
      </motion.div>
      <motion.div
        variants={fadeIn("left", "tween", 0.2, 1)}
        className="flex-1 flex justify-center flex-col"
      >
        
        <TitleText title={<>Karina, core of Typhon</>} />
        <h1 className="font-normal text-[24px] text-secondary-white">At the core of Typhon is Karina, is the first AI agent in Typhon ecosystem designed to analyze cryptocurrency markets using machine learning techniques and big data analysis</h1>
        <h1 className="font-normal text-[24px] text-secondary-white">The agent collects data from various trading platforms, analyzes market trends, detects price patterns, and identifies buying and selling opportunities based on well-researched trading strategies. It provides real-time, accurate recommendations to help investors and traders make informed decisions, enhancing investment performance and reducing risks .
Karina can interact with you both verbally and in writing in a natural and seamless manner. Whether you are a beginner or an experienced trader</h1>
        <div className="mt-[31px] flex flex-col max-w-[370px] gap-[24px]">
        </div>
      </motion.div>
    </motion.div>
  </section>
);

export default GetStarted;
